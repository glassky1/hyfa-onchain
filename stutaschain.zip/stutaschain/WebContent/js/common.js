﻿//打开字滑入效果
window.onload = function(){
	$(".connect p").eq(0).animate({"left":"0%"}, 600);
	$(".connect p").eq(1).animate({"left":"0%"}, 400);
};
//jquery.validate表单验证
$(document).ready(function(){
	//登陆表单验证
	$("#loginForm").validate({
		rules:{
			school_username:{
				required:true,//必填
				minlength:3, //最少3个字符
				maxlength:32,//最多32个字符
			},
			password:{
				required:true,
				minlength:3, 
				maxlength:32,
			},
			student_ID:{
				required:true,//必填
				minlength:18, //最少18个字符
				maxlength:18,//最多18个字符
			},	
			shool_name:{
				required:true,
				minlength:3,
				maxlength:18,
			},
			school_number:{
				required:true,
				school_number:true,//自定义的规则
				digits:true,//整数
			}
			
		},
		//错误信息提示
		messages:{
			school_username:{
				required:"必须填写用户名",
				minlength:"用户名至少为3个字符",
				maxlength:"用户名至多为32个字符",
			},
			password:{
				required:"必须填写密码",
				minlength:"密码至少为3个字符",
				maxlength:"密码至多为32个字符",
			},
			student_ID:{
				required:"必须填写身份证号",
				minlength:"身份证号应为18个字符",
				maxlength:"身份证号应为18个字符",
			},		
			school_number:{
				required:"必须填写学校代码",
				school_number:"学校代码格式错误",//自定义的规则
				digits:"学校代码格式错误",//整数
			},
			shool_name:{
				required:"请输入学校名称",
				minlength:"学校名称格式错误",
				maxlength:"学校名称格式错误",
			},
			
		},

	});
	//注册表单验证
	$("#registerForm").validate({
		rules:{
			student_username:{
				required:true,//必填
				minlength:1,
				},
			
			student_ID:{
				required:true,//必填
				minlength:18, //最少18个字符
				maxlength:18,//最多18个字符
				remote:{
					url:"http://kouss.com/demo/Sharelink/remote.json",//身份证号重复检查，别跨域调用
					type:"post",
				},
			},
			password:{
				required:true,
				minlength:3, 
				maxlength:32,
			},
			school_name:{
				required:true,
				minlength:3,
			},
			confirm_password:{
				required:true,
				minlength:3,
				equalTo:'.password'
			},
			school_number:{
				required:true,
				school_number:true,//自定义的规则
				digits:true,//整数
			}
		},
		//错误信息提示
		messages:{
			student_username:{
				required:"必须填写姓名",
				minlength:"必须填写姓名",
			},
			password:{
				required:"必须填写密码",
				minlength:"密码至少为3个字符",
				maxlength:"密码至多为32个字符",
			},
			shool_name:{
				required:"必须填写学校名称",
				minlength:3,
			},
			confirm_password:{
				required: "请再次输入密码",
				minlength: "确认密码不能少于3个字符",
				equalTo: "两次输入密码不一致",//与另一个元素相同
			},
			school_number:{
				required:"必须填写学校代码",
				digits:"学校代码格式错误",
				school_number:"学校代码格式错误",
			},
			student_ID:{
				required:"必须填写身份证号",
				minlength:"身份证号应为18个字符",
				maxlength:"身份证号应为18个字符",
				remote:"该身份证号已被注册",
			}
		
		},
	});
	//添加自定义验证规则
	
});
