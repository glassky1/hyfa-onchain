jQuery(".listnoticenbb>li").each(function(){
	jQuery(this).find("dd").children("a").show();
})

function switchDept(ProTag, ProBox) {
	for (i = 1; i < 5; i++) {
		if ("dept" + i == ProTag) {
			document.getElementById(ProTag).className = "current";
		} else {
			document.getElementById("dept" + i).className = "";
		}
		if ("deptcon" + i == ProBox) {
			document.getElementById(ProBox).style.display = "";
		} else {
			document.getElementById("deptcon" + i).style.display = "none";
		}
	}
}

jQuery(".hyitem").mouseover(function(){
	jQuery(this).find("td").children(".hyhide").show();
});
jQuery(".hyitem").mouseleave(function(){
	jQuery(this).find("td").children(".hyhide").hide();
});