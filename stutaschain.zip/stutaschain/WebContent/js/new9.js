var mainCategroy = {init: function (element) {
//           var me = this;
//                element.on('mouseenter', '.catblock', function (e) {
//                    var target = jQuery(e.currentTarget);
//                    target.find('.hot-query-layer').fadeIn();
//                    target.addClass(me.getItemHoverClass(target));
//                }).on('mouseleave', '.catblock', function (e) {
//                    var target = jQuery(e.currentTarget);
//                    target.removeClass(me.getItemHoverClass(target));
//                    target.find('.hot-query-layer').fadeOut();
//                });
//            },
//            getItemHoverClass: function (target) {
//                var type = target.data('type');
//                return type + '-item-hover';
            }
        };
 
 
//
//
jQuery('.newstab li').mouseover(function(){
	var el_index=jQuery(this).parent().find('li').index(this);
	jQuery(this).parent().find('li').removeClass('active');
	jQuery(this).addClass('active');
	jQuery(this).parent().parent().find("div.tabinfo").hide();
	jQuery(this).parent().parent().find("div.tabinfo").eq(el_index).show();
});
jQuery('.tabinfotab .tabinner').mouseover(function(){
	var el_index=jQuery(this).parent().find('.tabinner').index(this);
	jQuery(this).parent().find('.tabinner').removeClass('active');
	jQuery(this).addClass('active');
	jQuery(this).parent().parent().find(".listkb").hide();
	jQuery(this).parent().parent().find(".listkb").eq(el_index).show();
});

jQuery(".loadmore .next").mouseover(function(){
		jQuery(".loadclick").slideToggle();
		jQuery(this).toggleClass("togclass");
	})
jQuery('.bxslider').bxSlider({
  minSlides: 1,
  maxSlides: 1,
  controls:false,
  pager:true
});


/*edit 150605*/
jQuery(".bordergray .catblock").each(function() {
    jQuery(".withicon").hover(function(){
    	jQuery(".bordergray .catblock").find(".catxqwdiv").css({"z-index":"9999"}).end().siblings().find(".catxqwdiv").css({"z-index":"2"})
		var status=jQuery(".bordergray .catblock").find(".hot-query-layer").css("display");
		if(status=="none"){
			jQuery(".bordergray .catblock").find(".hot-query-layer").fadeIn();
			jQuery(".bordergray .catblock").find(".hot-query-layer").prev().css({"background-image":"linear-gradient(to bottom, #fff, #fff)","box-shadow":"0 0 15px #fff"});
			//jQuery(".bordergray .catblock").prev().css({"background":"#c00"});
		}
	},function(){
		jQuery(".bordergray .catblock").find(".hot-query-layer").fadeOut();
		jQuery(".bordergray .catblock").find(".hot-query-layer").prev().css({"background-image":"linear-gradient(to bottom, #fff, #f6f6f6)","box-shadow":"0 0 transparent"});
	})
});

jQuery(".toutiao").hide();
jQuery(".listnotice>li").each(function(){
	jQuery(this).find("dd:first").children("a").hide().end().css({"background":"none"});
	jQuery(this).find("dd:first").find(".toutiao").show();
	jQuery(this).find("dd:not([class*='more'])").each(function(){
		jQuery(this).hover(function(){
			jQuery(this).find(".toutiao").show().end().siblings().find(".toutiao").hide();
			jQuery(this).children("a").hide().end().siblings().children("a").show();
			jQuery(this).css({"background":"none"}).siblings().css({"background":"rgba(0, 0, 0, 0) url('bul/images/sprite.png') no-repeat scroll 10px -980px"});
		},function(){
			//jQuery(this).css({"background":"rgba(0, 0, 0, 0) url('images/sprite.png') no-repeat scroll 10px -980px"});
		})
	})
})

