package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class StoreServlet2 extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse reponse)
			throws ServletException,IOException{
		String id=request.getParameter("id");
		//修改数据库
		try {
			Connection con=new GetConnection().getConnection();
			
			PreparedStatement pst1=con.prepareStatement("update stuinfo set prischool=? where id=?");
			pst1.setString(1, (String)request.getParameter("prischool"));
			pst1.setString(2, id);
			pst1.execute();
			pst1.close();
			
			PreparedStatement pst2=con.prepareStatement("update stuinfo set prischool_year=? where id=?");
			pst2.setString(1,(String)request.getParameter("prischool_year"));
			pst2.setString(2,id);
			pst2.execute();
			pst2.close();
			
			PreparedStatement pst3=con.prepareStatement("update stuinfo set priteacher=? where id=?");
			pst3.setString(1, (String)request.getParameter("priteacher"));
			pst3.setString(2, id);
			pst3.execute();
			pst3.close();
			
			PreparedStatement pst4=con.prepareStatement("update stuinfo set midschool=? where id=?");
			pst4.setString(1, (String)request.getParameter("midschool"));
			pst4.setString(2, id);
			pst4.execute();
			pst4.close();
			
			PreparedStatement pst5=con.prepareStatement("update stuinfo set midschool_year=? where id=?");
			pst5.setString(1, (String)request.getParameter("midschool_year"));
			pst5.setString(2, id);
			pst5.execute();
			pst5.close();
			
			PreparedStatement pst6=con.prepareStatement("update stuinfo set midteacher=? where id=?");
			pst6.setString(1, (String)request.getParameter("midteacher"));
			pst6.setString(2, id);
			pst6.execute();
			pst6.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//重新跳转会renew页面,主要是重新设置session的内容
		
		HttpSession session=request.getSession();
		session.setAttribute("prischool",(String)request.getParameter("prischool"));
		session.setAttribute("prischool_year",(String) request.getParameter("prischool_year"));
		session.setAttribute("priteacher",(String)request.getParameter("priteacher"));
		session.setAttribute("midschool",(String)request.getParameter("midschool") );
		session.setAttribute("midschool_year", (String)request.getParameter("midschool_year"));
		session.setAttribute("midteacher", (String)request.getParameter("midteacher"));
		reponse.sendRedirect("./renew2.jsp");
		
		
		
		
	}
}