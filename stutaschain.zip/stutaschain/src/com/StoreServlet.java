package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


	public class StoreServlet extends HttpServlet {
		public void doGet(HttpServletRequest request,HttpServletResponse reponse)
				throws ServletException,IOException{
			String id=request.getParameter("id");
			PrintWriter pw=reponse.getWriter();
			//修改数据库
			try {
				Connection con=new GetConnection().getConnection();
				
				PreparedStatement pst1=con.prepareStatement("update stutas set name=? where id=?");
				pst1.setString(1, (String)request.getParameter("name"));
				pst1.setString(2, id);
				pst1.execute();
				pst1.close();
				
				PreparedStatement pst2=con.prepareStatement("update stuinfo set gender=? where id=?");
				pst2.setString(1, (String)request.getParameter("gender"));
				pst2.setString(2, id);
				pst2.execute();
				pst2.close();
				
				PreparedStatement pst3=con.prepareStatement("update stuinfo set politics=? where id=?");
				pst3.setString(1, (String)request.getParameter("politics"));
				pst3.setString(2, id);
				pst3.execute();
				pst3.close();
				
				PreparedStatement pst4=con.prepareStatement("update stuinfo set nation=? where id=?");
				pst4.setString(1, (String)request.getParameter("nation"));
				pst4.setString(2, id);
				pst4.execute();
				pst4.close();
				
				PreparedStatement pst5=con.prepareStatement("update stutas set schoolname=? where id=?");
				pst5.setString(1, (String)request.getParameter("schoolname"));
				pst5.setString(2, id);
				pst5.execute();
				pst5.close();
				
				PreparedStatement pst6=con.prepareStatement("update stuinfo set number=? where id=?");
				pst6.setString(1, (String)request.getParameter("number"));
				pst6.setString(2, id);
				pst6.execute();
				pst6.close();
				
				PreparedStatement pst7=con.prepareStatement("update stuinfo set getinschool=? where id=?");
				pst7.setString(1, (String)request.getParameter("getinschool"));
				pst7.setString(2, id);
				pst7.execute();
				pst7.close();
				
				PreparedStatement pst8=con.prepareStatement("update stuinfo set grade=? where id=?");
				pst8.setString(1, (String)request.getParameter("grade"));
				pst8.setString(2, id);
				pst8.execute();
				pst8.close();
				
				PreparedStatement pst9=con.prepareStatement("update stuinfo set choice=? where id=?");
				pst9.setString(1, (String)request.getParameter("choice"));
				pst9.setString(2, id);
				pst9.execute();
				pst9.close();
				
				
				//pw.print((String)request.getParameter("getinschool"));
				//pw.print(id);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			//重新跳转会renew页面,主要是重新设置session的内容
			
			HttpSession session=request.getSession();
			session.setAttribute("name",(String)request.getParameter("name"));
			session.setAttribute("gender",(String) request.getParameter("gender"));
			session.setAttribute("politics",(String)request.getParameter("politics"));
			session.setAttribute("nation",(String)request.getParameter("nation") );
			session.setAttribute("schoolname", (String)request.getParameter("schoolname"));
			session.setAttribute("number", (String)request.getParameter("number"));
			session.setAttribute("getinschool", (String)request.getParameter("getinschool"));
			session.setAttribute("grade",(String)request.getParameter("grade"));
			session.setAttribute("choice", (String)request.getParameter("choice"));
			reponse.sendRedirect("./renew1.jsp");
			
			
			
			
		}
}

