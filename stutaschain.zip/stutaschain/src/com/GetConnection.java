package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class GetConnection {

	
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		//连接数据库的类，可以根据自身配置更改
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/mydb?useSSL=false";
		Connection conn=DriverManager.getConnection(url,"root","12345678");
		return conn;
	}
}
