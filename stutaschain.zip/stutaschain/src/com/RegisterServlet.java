package com;

import java.io.IOException;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RegisterServlet extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse reponse)
			throws ServletException,IOException{
		List<String> usernumList = new ArrayList<String>();
		String student_username =request.getParameter("student_username");
		String student_ID =request.getParameter("student_ID"); //unique字段
		String password =request.getParameter("password");
		String confirm_password =request.getParameter("confirm_password");
		String shool_name =request.getParameter("shool_name");
		String shcool_number= request.getParameter("shcool_number");
		HttpSession session=request.getSession();
		try {
			Connection con1=new GetConnection().getConnection();
			
			//检查是否已经存在用户，存在则返回失败
			Statement st=con1.createStatement();
			ResultSet rs = st.executeQuery("select id from stutas");
			while (rs.next()) {
                usernumList.add(rs.getString(1));
            }
			if (usernumList.contains(student_ID)) {
				//此部分准备用ajax完善!!!!!!!!
				session.setAttribute("isExist", "true");
				reponse.sendRedirect("register.jsp");
            }
			
			else {
				//新用户则存入用户
				
				PreparedStatement storeSt=con1.prepareStatement("insert into stutas values(?,?,?,?,?)");
				
				storeSt.setString(1, student_username);
				storeSt.setString(2, student_ID);
				storeSt.setString(3, password);
				storeSt.setString(4, shool_name);
				storeSt.setString(5, shcool_number);
				storeSt.execute();
				storeSt.close();
				//为stuIndo也插入索引
				PreparedStatement Append=con1.prepareStatement("insert into stuInfo(id) values(?)");
				Append.setString(1, student_ID);
				Append.execute();
				request.setAttribute("isExist", "false");
				RequestDispatcher dispatch=request.getRequestDispatcher("/register.jsp");
				dispatch.forward(request, reponse);
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
