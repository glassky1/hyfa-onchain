package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet {
	public void doGet(HttpServletRequest request,HttpServletResponse reponse)
			throws ServletException,IOException{
		List<String> usernumList = new ArrayList<String>();
		String student_ID =request.getParameter("student_ID"); 
		String password =request.getParameter("password");
		Connection con1 = null;
		HttpSession session=request.getSession();
		
		try {
			con1 = new GetConnection().getConnection();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Statement st;
		
		
			try {
				
				st = con1.createStatement();
				ResultSet rs = st.executeQuery("select id from stutas");
				while (rs.next()) {
	                usernumList.add(rs.getString(1));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//验证有无该账号
		if(usernumList.contains(student_ID)) {
			//有账号的情况下,进行密码检查
			try {
				//获得登陆ID的密码
				PreparedStatement pst=con1.prepareStatement("select password from stutas where id=?");
				pst.setString(1, student_ID);
				ResultSet SQLPW=pst.executeQuery();
				SQLPW.next();
				String SQLpassword=SQLPW.getString(1);
				
				if(SQLpassword.equals(password)) {
					//密码正确处理
					String sql="select name,schoolname,gender,politics,nation,getinschool,grade,choice,number,prischool,prischool_year,midschool,midschool_year,priteacher,midteacher "
							+ "from stutas join stuInfo on stutas.id=stuInfo.id where stutas.id=?";
					PreparedStatement pstForAll=con1.prepareStatement(sql);
					pstForAll.setString(1, student_ID);
					ResultSet SQLAll=pstForAll.executeQuery();
					SQLAll.next();
					
					session.setAttribute("name", SQLAll.getString(1));
					session.setAttribute("schoolname", SQLAll.getString(2));
					session.setAttribute("gender", SQLAll.getString(3));
					session.setAttribute("politics", SQLAll.getString(4));
					session.setAttribute("nation", SQLAll.getString(5));
					session.setAttribute("getinschool", SQLAll.getString(6));
					session.setAttribute("grade", SQLAll.getString(7));
					session.setAttribute("choice", SQLAll.getString(8));
					session.setAttribute("id", student_ID);
					session.setAttribute("number", SQLAll.getString(9));
					session.setAttribute("prischool", SQLAll.getString(10));
					session.setAttribute("prischool_year", SQLAll.getString(11));
					session.setAttribute("midschool", SQLAll.getString(12));
					session.setAttribute("midschool_year", SQLAll.getString(13));
					session.setAttribute("priteacher", SQLAll.getString(14));
					session.setAttribute("midteacher", SQLAll.getString(15));
					RequestDispatcher dispatch=request.getRequestDispatcher("/stuInfo.jsp");
					dispatch.forward(request, reponse);
				}
				else {
					//密码错误处理
					RequestDispatcher dispatch=request.getRequestDispatcher("/index1.jsp");
					session.setAttribute("loginException", "wrongPW");
					dispatch.forward(request, reponse);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else {
			//没有账号的处理
			RequestDispatcher dispatch=request.getRequestDispatcher("/index1.jsp");
			session.setAttribute("loginException", "noneUser");
			dispatch.forward(request, reponse);
		}
	}
}